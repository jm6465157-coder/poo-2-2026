<?php
/* configurar el paginado */
$registrosPorPagina = 5;
// Obtener el Numero de pagina
$pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
// Evitar que se utilicen paginas menores que 1
if ($pagina < 1) {
    $pagina = 1;
}
// Contar total de Registros
$sqlTotal = "SELECT COUNT(*) AS total FROM usuarios AS u INNER JOIN roles AS r ON u.idrol = r.idrol";
$dataTotal = CRUD($sqlTotal, "s");
$totalRegistros = $dataTotal[0]['total'] ?? 0;

// Calcular Total de paginas
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);

// Validar la ultima pagina
if ($totalPaginas > 0 && $pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}
//OFFSET
$offset = ($pagina - 1) * $registrosPorPagina;

$sql = "SELECT * FROM usuarios AS u INNER JOIN roles AS r ON u.idrol = r.idrol ORDER BY u.idusuario ASC LIMIT $registrosPorPagina OFFSET $offset";

$dataUsuarios = CRUD($sql, "S");
?>
<a href="" class="btn btn-primary btn-sm">
<i class="fa-solid fa-user-plus"></i>
</a>
<hr>
<div class="table-responsive">
    <table class="table table-borderless table-bordered table-hover table-sm" border="1" style="border-collapse: collapse;">
        <thead class="table-dark p-3">
            <tr>
                <th class="ccv">ID</th>
                <th class="ccv">Usuario</th>
                <th class="ccv">Email</th>
                <th class="ccv">Rol</th>
                <th class="ccv">Estado</th>
                <th class="ccv" colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataUsuarios as $resultado): ?>
                <tr>
                    <td><?= $resultado['idusuario']; ?></td>
                    <td><?= $resultado['usuario']; ?></td>
                    <td><?= $resultado['email']; ?></td>
                    <td><?= $resultado['rol']; ?></td>
                    <td><?= ($resultado['estado'] == 1) ? 'Activo' : 'Inactivo'; ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if ($totalRegistros > 0): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <small class="text-muted">
                    Página <strong><?= $pagina; ?></strong> de <strong><?= $totalPaginas; ?></strong> | Total de
                    registros <strong><?= $totalRegistros ?></strong>
                </small>
            </div>
            <nav aria-label="Pagina de Usuarios">
                <ul class="pagination pagination-sm mb-0">
                    <!--Boton Regresar-->
                    <?php if ($pagina > 1): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina - 1); ?>" class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </span>
                        </li>
                    <?php endif; ?>
                    <!--Boton con numero de paginas-->
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <?php if ($i == $pagina): ?>
                            <li class="page-item active">
                                <span class="page-link">
                                    <?= $i; ?>
                                </span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="?page=<?= $i ?>" class="page-link">
                                    <?= $i; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <!--boton de siguiente -->
                    <?php if ($pagina < $totalPaginas): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina + 1); ?>" class="page-link"> 
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </span>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>