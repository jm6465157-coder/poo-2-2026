<?php
$idempleado = $_POST['idempleado'];

$dataEmpleados = CRUD("SELECT * FROM empleados WHERE idempleado = $idempleado", "S");

foreach ($dataEmpleados as $result) {
    $nombre = $result['nombre'];
    $dui = $result['dui'];
    $telefono = $result['telefono'];
    $correo = $result['correo'];
    $cargo = $result['cargo'];
    $estado = $result['estado'];
}
?>

<div class="row">
    <div class="col-md-4"></div>

    <div class="col-md-4">
        <form action="../../controllers/empleadosControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Empleado:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="nombre"
                    value="<?= $nombre ?>"
                    placeholder="Ingrese el nombre de empleado"
                    required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>DUI:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="dui"
                    value="<?= $dui ?>"
                    placeholder="Ingrese el DUI"
                    required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Teléfono:</b>
                </span>
                <textarea
                    class="form-control"
                    name="telefono"
                    placeholder="Ingrese el teléfono"
                    required><?= $telefono ?></textarea>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Correo:</b>
                </span>
                <textarea
                    class="form-control"
                    name="correo"
                    placeholder="Ingrese el correo electrónico"
                    required><?= $correo ?></textarea>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Cargo:</b>
                </span>
                <textarea
                    class="form-control"
                    name="cargo"
                    placeholder="Ingrese el cargo"
                    required><?= $cargo ?></textarea>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="estado">
                    <b>Estado:</b>
                </label>

                <select class="form-select" id="estado" name="estado" required>
                    <option value="1" <?= ($estado == 1) ? 'selected' : '' ?>>
                        Activo
                    </option>
                    <option value="0" <?= ($estado == 0) ? 'selected' : '' ?>>
                        Inactivo
                    </option>
                </select>
            </div>

            <input type="hidden" name="idempleado" value="<?= $idempleado ?>">
            <input type="hidden" name="U_U" value="1">

            <button type="submit" class="btn btn-primary" name="U_U" value="1">
                Actualizar
            </button>

            <a href="../../views/empleados/index.php" class="btn btn-danger">
                Cancelar
            </a>

        </form>
    </div>

    <div class="col-md-4"></div>
</div>