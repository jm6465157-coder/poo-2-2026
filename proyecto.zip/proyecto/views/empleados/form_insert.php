
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Empleado: </b>
  </span>
  <input type="text" class="form-control" name="nombre" placeholder="Ingrese  de empleado" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Dui: </b>
  </span>
  <input type="text" class="form-control" name="dui" placeholder="Ingrese su dui" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Teléfono: </b>
  </span>
  <textarea class="form-control" name="telefono" placeholder="Ingrese el teléfono" required></textarea>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Email: </b>
  </span>
  <textarea class="form-control" name="correo" placeholder="Ingrese el email" required></textarea>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Cargo: </b>
  </span>
  <textarea class="form-control" name="cargo" placeholder="Ingrese el cargo" required></textarea>
</div>

<div class="input-group mb-3">
    <span class="input-group-text"><b>Estado:</b></span>
    <select class="form-select" name="estado" required>
        <option value="1" selected>Activo</option>
        <option value="0">Inactivo</option>
    </select>
</div>
<input type="hidden" name="I_E" value="1">