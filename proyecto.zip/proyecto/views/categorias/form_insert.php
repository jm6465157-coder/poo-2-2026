
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Nombre: </b>
  </span>
  <input type="text" class="form-control" name="nombre" placeholder="Ingrese el nombre de la categoría" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Descripción: </b>
  </span>
  <input type="text" class="form-control" name="descripcion" placeholder="Ingrese la descripción de la categoría" required>
</div>

<div class="input-group mb-3">
    <span class="input-group-text"><b>Estado: </b></span>
    <select class="form-select" name="estado" required>
        <option value="1" selected>Activo</option>
        <option value="0">Inactivo</option>
    </select>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Fecha de creación: </b>
  </span>
  <textarea class="form-control" name="fecha_creacion" placeholder="Ingrese la fecha de creación" required></textarea>
</div>

<input type="hidden" name="I_C" value="1">