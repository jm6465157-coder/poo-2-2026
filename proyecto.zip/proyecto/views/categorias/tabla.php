<?php
/* configurar el paginado */
$registrosPorPagina = 3;
// Obtener el Número de página
$pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
// Evitar que se utilicen páginas menores que 1
if ($pagina < 1) {
    $pagina = 1;
}
// Contar total de Registros de categorías
$sqlTotal = "SELECT COUNT(*) AS total FROM categorias";
$dataTotal = CRUD($sqlTotal, "s");
$totalRegistros = $dataTotal[0]['total'] ?? 0;

// Calcular Total de páginas
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);

// Validar la última página
if ($totalPaginas > 0 && $pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}
// OFFSET
$offset = ($pagina - 1) * $registrosPorPagina;

$sql = "SELECT * FROM categorias ORDER BY idcategoria ASC LIMIT $registrosPorPagina OFFSET $offset";

$dataCategorias = CRUD($sql, "S");
?>
<a href="" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#ModalInsertCategoria">
    <i class="fa-solid fa-folder-plus"></i>
</a>
<hr>
<div class="table-responsive">
    <table class="table table-borderless table-bordered table-hover table-sm" border="1" style="border-collapse: collapse;">
        <thead class="table-dark p-3">
            <tr>
                <th class="ccv">ID</th>
                <th class="ccv">Nombre</th>
                <th class="ccv">Descripción</th>
                <th class="ccv">Fecha Creación</th>
                <th class="ccv">Estado</th>
                <th class="ccv">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataCategorias as $resultado): ?>
                <tr>
                    <td><?= $resultado['idcategoria']; ?></td>
                    <td><?= $resultado['nombre']; ?></td>
                    <td><?= $resultado['descripcion']; ?></td>
                    <td><?= $resultado['fecha_creacion']; ?></td>
                    <td><?= ($resultado['estado'] != 0) ? 'Activo' : 'Inactivo'; ?></td>
                    <td>
                        <form action="?page=<?= $pagina ?>" method="post">
                            <input type="hidden" name="idcategoria" value="<?= $resultado['idcategoria'] ?>">
                            <input type="hidden" name="nombre" value="<?= $resultado['nombre'] ?>">
                            <input type="hidden" name="descripcion" value="<?= $resultado['descripcion'] ?>">
                            <input type="hidden" name="estado" value="<?= $resultado['estado'] ?>">
                            <button class="btn btn-success btn-sm" name="btn_update_categoria">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if ($totalRegistros > 0): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <small class="text-muted">
                    Página <strong><?= $pagina; ?></strong> de <strong><?= $totalPaginas; ?></strong> | Total de
                    registros <strong><?= $totalRegistros ?></strong>
                </small>
            </div>
            <nav aria-label="Pagina de Categorias">
                <ul class="pagination pagination-sm mb-0">
                    <!-- Botón Regresar -->
                    <?php if ($pagina > 1): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina - 1); ?>" class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </span>
                        </li>
                    <?php endif; ?>
                    <!-- Botón con número de páginas -->
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <?php if ($i == $pagina): ?>
                            <li class="page-item active">
                                <span class="page-link">
                                    <?= $i; ?>
                                </span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="?page=<?= $i ?>" class="page-link">
                                    <?= $i; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <!-- Botón de siguiente -->
                    <?php if ($pagina < $totalPaginas): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina + 1); ?>" class="page-link">
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </span>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>