<?php
$idcategoria = $_POST['idcategoria'];
$dataCategoria = CRUD("SELECT * FROM categorias WHERE idcategoria = $idcategoria", "s");
foreach ($dataCategoria as $result) {
    $nombre = $result['nombre'];
    $descripcion = $result['descripcion'];
    $estado = $result['estado'];
}
?>
<div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <form action="../../controllers/categoriasControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">
                    <b>Nombre: </b>
                </span>
                <input type="text" class="form-control" name="nombre" value="<?= $nombre ?>"
                    placeholder="Ingrese el nombre de la categoría" required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Descripción: </b>
                </span>
                <textarea class="form-control" name="descripcion" placeholder="Ingrese la descripción" required><?= $descripcion ?></textarea>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="inputGroupSelect01">
                    <b>Estado: </b>
                </label>
                <select class="form-select" id="estado" name="estado" required>
                    <option value="1" <?= ($estado == 1) ? 'selected' : '' ?>>Activo</option>
                    <option value="0" <?= ($estado == 0) ? 'selected' : '' ?>>Inactivo</option>
                </select>
            </div>

            <input type="hidden" name="U_C" value="1">
            <input type="hidden" name="idcategoria" value="<?= $idcategoria ?>">

            <button class="btn btn-primary">Actualizar</button>
            <a href="../categorias/index.php" class="btn btn-danger">Cancelar</a>
        </form>
    </div>
    <div class="col-md-4"></div>
</div>