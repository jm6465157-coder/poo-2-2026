<?php
$idcategoria = $_POST['idcategoria'];

$dataCategorias = CRUD("SELECT * FROM categorias WHERE idcategoria = $idcategoria", "S");

foreach ($dataCategorias as $result) {
    $nombre = $result['nombre'];
    $descripcion = $result['descripcion'];
    $estado = $result['estado'];
    $fecha_creacion = $result['fecha_creacion'];
}
?>

<div class="row">
    <div class="col-md-4"></div>

    <div class="col-md-4">
        <form action="../../controllers/categoriasControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Categoría:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="nombre"
                    value="<?= $nombre ?>"
                    placeholder="Ingrese el nombre de la categoría"
                    required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Descripción:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="descripcion"
                    value="<?= $descripcion ?>"
                    placeholder="Ingrese la descripción de la categoría"
                    required>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="estado">
                    <b>Estado:</b>
                </label>

                <select class="form-select" id="estado" name="estado" required>
                    <option value="1" <?= ($estado == 1) ? 'selected' : '' ?>>
                        Activo
                    </option>
                    <option value="0" <?= ($estado == 0) ? 'selected' : '' ?>>
                        Inactivo
                    </option>
                </select>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Fecha de creación:</b>
                </span>
                <textarea
                    class="form-control"
                    name="fecha_creacion"
                    placeholder="Ingrese la fecha de creación"
                    required><?= $fecha_creacion ?></textarea>
            </div>


            <input type="hidden" name="idcategoria" value="<?= $idcategoria ?>">
            <input type="hidden" name="U_U" value="1">

            <button type="submit" class="btn btn-primary" name="U_U" value="1">
                Actualizar
            </button>

            <a href="../../views/categorias/index.php" class="btn btn-danger">
                Cancelar
            </a>

        </form>
    </div>

    <div class="col-md-4"></div>
</div>