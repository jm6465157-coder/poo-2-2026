<div class="card mt-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <p class="mb-0"><b>Bienvenido/a:</b></p>

        <form action="index.php" method="POST"
            onsubmit="return confirm('¿Desea cerrar sesión?')">
            <input type="hidden" name="off" value="1">

            <button type="submit" class="btn btn-danger btn-sm">
                <i class="fa-solid fa-right-from-bracket"></i>
            </button>
        </form>
    </div>

    <div class="card-body">
        <div class="row">

            <!-- Panel de usuarios -->
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <b>Panel de usuarios</b>
                    </div>

                    <div class="card-body text-center">
                        <a href="./views/usuarios/index.php"
                            class="btn btn-primary">
                            <i class="fa-solid fa-users fa-2x"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Panel de empleados -->
            <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <b>Panel de empleados</b>
                    </div>

                    <div class="card-body text-center">
                        <a href="./views/empleados/index.php"
                            class="btn btn-primary">
                            <i class="fa-solid fa-user-tie fa-2x"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Panel de categorias -->
               <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <b>Panel de categorias</b>
                    </div>

                    <div class="card-body text-center">
                        <a href="./views/categorias/index.php"
                            class="btn btn-primary">
                           <i class="fa-solid fa-tags fa-2x"></i>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Panel de proveedores -->
             <div class="col-md-4 mb-3">
                <div class="card h-100">
                    <div class="card-header text-center">
                        <b>Panel de proveedores</b>
                    </div>

                    <div class="card-body text-center">
                        <a href="./views/proveedores/index.php"
                            class="btn btn-primary">
                           <i class="fa-solid fa-building fa-2x"></i>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>