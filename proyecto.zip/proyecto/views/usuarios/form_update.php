<?php
$idusuario = $_POST['idusuario'];

$dataUser = CRUD("SELECT * FROM usuarios WHERE idusuario = $idusuario", "S");

foreach ($dataUser as $result) {
    $usuario = $result['usuario'];
    $email = $result['email'];
    $idrol = $result['idrol'];
    $estado = $result['estado'];
}

$dataRoles = CRUD("SELECT * FROM roles WHERE estadoR != 0", "S");
?>

<div class="row">
    <div class="col-md-4"></div>

    <div class="col-md-4">
        <form action="../../controllers/usuariosControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Usuario:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="usuario"
                    value="<?= $usuario ?>"
                    placeholder="Ingrese el nombre de usuario"
                    required
                >
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Contraseña:</b>
                </span>
                <input
                    type="password"
                    class="form-control"
                    name="passw"
                    placeholder="Ingrese la contraseña"
                >
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Email:</b>
                </span>
                <textarea
                    class="form-control"
                    name="email"
                    placeholder="Ingrese el email"
                    required
                ><?= $email ?></textarea>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="rol">
                    <b>Rol:</b>
                </label>

                <select class="form-select" id="rol" name="rol" required>
                    <?php foreach ($dataRoles as $resultRol): ?>
                        <option
                            value="<?= $resultRol['idrol'] ?>"
                            <?= ($idrol == $resultRol['idrol']) ? 'selected' : '' ?>
                        ><?= $resultRol['rol'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="hidden" name="U_U" value="1">
            <input type="hidden" name="idusuario" value="<?= $idusuario ?>">

            <button type="submit" class="btn btn-primary" name="U_U" value="1">
                Actualizar
            </button>

            <a href="../../views/usuarios/index.php" class="btn btn-danger">
                Cancelar
            </a>

        </form>
    </div>

    <div class="col-md-4"></div>
</div>