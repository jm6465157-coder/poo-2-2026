<?php
$idusuario = $_POST['idusuario'];
$dataUser = CRUD("SELECT * FROM usuarios WHERE idusuario = $idusuario", "s");
foreach ($dataUser as $result) {
    $usuario = $result['usuario'];
    $email = $result['email'];
    $idrol = $result['idrol'];
    $estado = $result['estado'];
}

$dataRoles = CRUD("SELECT * FROM roles WHERE estado != 0", "s");
?>
<div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <form action="../../controllers/usuariosControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">
                    <b>Usuario: </b>
                </span>
                <input type="text" class="form-control" name="usuario" value="<?= $usuario ?>"
                    placeholder="Ingrese el nombre de usuario" required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">
                    <b>Contraseña: </b>
                </span>
                <input type="text" class="form-control" name="passw" placeholder="Ingrese la contraseña">
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Email: </b>
                </span>
                <textarea class="form-control" name="email" placeholder="ingresa el email" required><?= $email ?></textarea>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="inputGroupSelect01">
                    <b>Rol: </b>
                </label>
                <select class="form-select" id="rol" name="rol" required>
                    <?php foreach ($dataRoles as $resultRol): ?>
                        <option value="<?= $resultRol['idrol'] ?>" <?= ($idrol == $resultRol['idrol']) ? 'selected' : '' ?>><?= $resultRol['rol'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="inputGroupSelect01">
                    <b>Estado: </b>
                </label>
                <select class="form-select" id="estado" name="estado" required>
                    <option value="1" <?= ($estado == 1) ? 'selected' : '' ?>>Activo</option>
                    <option value="0" <?= ($estado == 0) ? 'selected' : '' ?>>Inactivo</option>
                </select>
            </div>

            <input type="hidden" name="U_U" value="1">
            <input type="hidden" name="idusuario" value="<?= $idusuario ?>">

            <button class="btn btn-primary">Actualizar</button>
            <a href="../usuarios/index.php" class="btn btn-danger">Cancelar</a>
        </form>
    </div>
    <div class="col-md-4"></div>
</div>