<?php

session_start();
include "../../models/conexion.php";
include "../../models/funciones.php";
include "../../controllers/funciones.php";



?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuarios</title>
    <!-- Bootstrap CSS -->
    <link rel="shortcut icon" href="../../public/img/crud.png" type="image/x-icon">
    <link rel="stylesheet" href="../../public/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../public/css/alertify.css">
    <link rel="stylesheet" href="../../public/css/default.css">
    <link rel="stylesheet" href="../../public/css/inputmask.min.css">
    <link rel="stylesheet" href="../../public/css/style.css">
    <!-- JS -->
    <script src="../../public/js/jquery-3.7.1.min.js"></script>
    <script src="../../public/js/bootstrap.bundle.min.js"></script>
    <script src="../../public/js/alertify.js"></script>
    <script src="../../public/js/inputmask.min.js"></script>
    <script src="../../public/js/jquery.inputmask.bundle.js"></script>
    <script src="../../public/js/fontawesome.js"></script>
</head>

<body id="toor">
    <div class="card mt-3 container">
        <div class="card-header">
            <p><b>Panel de Usuarios</b></p>

            <a href="../../index.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-circle-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">
            <?php include './tabla.php';

            ?>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="ModalInsertUser" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollabl">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

</body>

</html>