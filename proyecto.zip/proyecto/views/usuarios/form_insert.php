<?php
?>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Usuario: </b>
  </span>
  <input type="text" class="form-control" name="categoria" placeholder="Ingrese el nombre de la categoria" required>
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Contraseña: </b>
  </span>
  <input type="text" class="form-control" name="passw" placeholder="Ingrese la contraseña" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Email: </b>
  </span>
  <textarea class="form-control" name="email" placeholder="ingresa el email" required></textarea>
</div>
<div class="input-group mb-3">
  <label class="input-group-text" for="inputGroupSelect01">
    <b>Rol: </b>
  </label>
  