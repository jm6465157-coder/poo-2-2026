<?php
if (!function_exists('CRUD')) {
    function CRUD($sql, $tipo = 'S')
    {
        return [];
    }
}

/* Configurar el paginado*/
$registrosPorPagina = 5;
// Obtener el numero de pagina
$pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;
// Evitar que se utilicen paginas menores que 1
if ($pagina < 1) {
    $pagina = 1;
}
// Contar Total de registros
$sqlTotal = "SELECT COUNT(*) AS total FROM usuarios AS u INNER JOIN roles AS r ON u.idrol=r.idrol";
$dataTotal = CRUD($sqlTotal, "S");
$totalRegistros = $dataTotal[0]['total'] ?? 0;

// Calcular total de paginas
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);
// Validar la ultima pagina
if ($totalPaginas > 0 && $pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}

//OFFSET
$offset = ($pagina - 1) * $registrosPorPagina;

$sql = "SELECT * FROM usuarios AS u INNER JOIN roles AS r ON u.idrol = r.idrol ORDER BY u.idusuario ASC LIMIT $registrosPorPagina OFFSET $offset";

$dataUsuarios = CRUD($sql, "S");
?>
<a href="crear.php" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#ModalInsertUser">
    <i class="fa-solid fa-user-plus"></i>
</a>
<hr>
<div class="table-responsive">
    <table class="table table-borderless table-bordered table-hover table-sm" border="1" style="border-collapse: collapse;">
        <thead class="table-dark P-3">
            <tr>
                <th class="ccv">ID</th>
                <th class="ccv">Usuario</th>
                <th class="ccv">Email</th>
                <th class="ccv">Rol</th>
                <th class="ccv">Estado</th>
                <th class="ccv" colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php

            foreach ($dataUsuarios as $resultado): ?>
                <tr>
                    <td><?= $idusuario = $resultado['idusuario']; ?></td>
                    <td><?= $resultado['usuario']; ?></td>
                    <td><?= $resultado['email']; ?></td>
                    <td><?= $resultado['rol']; ?></td>
                    <td><?= ($resultado['estado'] != 0) ? 'Activo' : 'Inactivo'; ?></td>
                    <td>
                        <form action="#" method="post">
                            <input type="hidden" name="idusuario" value="<?= $idusuario; ?>">
                            <button class="btn btn-success btn-sm" name="Btn_Update_User">
                                <i class="fa-solid fa-user-pen"></i>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form action="../../controllers/usuariosControllers.php" method="post">
                            <input type="hidden" name="idusuario" value="<?= $idusuario; ?>">
                            <?php
                            if ($resultado['estado'] == 1) {
                                $valorE = 0;
                                $valorB = "warning";
                                $valorI = "slash";
                            } else {
                                $valorE = 1;
                                $valorB = "info";
                                $valorI = "check";
                            }

                            ?>
                            <input type="hidden" name="valorE" value="<?= $valorE; ?>">
                            <button class="btn btn-<?= $valorB; ?> btn-sm" name="Btn_B_A_User">
                                <i class="fa-solid fa-user-<?= $valorI ?>"></i>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form action="../../controllers/usuariosControllers.php" method="post" onsubmit="return confirm('Esta seguro/a de eliminar este usurio');">
                            <input type="hidden" name="idusuario" value="<?= $idusuario; ?>">
                            <button class="btn btn-danger btn-sm" name="Btn_Delete_User">
                                <i class="fa-solid fa-user-xmark"></i>
                            </button>
                        </form>
                    </td>
                    </td>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if ($totalRegistros > 0): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <small class="text-muted">
                    Pagina <strong><?= $pagina; ?></strong> de <strong><?= $totalPaginas; ?></strong> | Total de registros: <strong><?= $totalRegistros; ?></strong>
                </small>
            </div>
            <nav aria-label="Paginación de usuarios">
                <ul class="pagination pagination-sm mb-0">
                    <!-- Boton Anterior -->
                    <?php if ($pagina > 1): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina - 1); ?>" class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="fa-solid fa-angle-left"></i> Anterior
                            </span>
                        </li>
                    <?php endif; ?>
                    <!-- Botones de paginación -->

                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <?php if ($i == $pagina): ?>
                            <li class="page-item active">
                                <span class="page-link">
                                    <?= $i; ?>
                                </span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="?page=<?= $i ?>" class="page-link">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <!-- Boton Siguiente -->
                    <?php if ($pagina < $totalPaginas): ?>
                        <li class="page-item">
                            <a href="?page=<?= ($pagina + 1); ?>" class="page-link">
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                Siguiente <i class="fa-solid fa-angle-right"></i>
                            </span>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>