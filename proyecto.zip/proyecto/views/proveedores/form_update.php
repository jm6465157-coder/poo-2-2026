<?php
$idproveedor = $_POST['idproveedor'];

$dataProveedores = CRUD("SELECT * FROM proveedores WHERE idproveedor = $idproveedor", "S");

foreach ($dataProveedores as $result) {
    $nombre = $result['nombre'];
    $nit = $result['nit'];
    $telefono = $result['telefono'];
    $correo = $result['correo'];
    $direccion = $result['direccion'];
    $contacto = $result['contacto'];
    $estado = $result['estado'];
    $fecha_creacion = $result['fecha_creacion'];
}
?>

<div class="row">
    <div class="col-md-4"></div>

    <div class="col-md-4">
        <form action="../../controllers/proveedorControllers.php" method="post">

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Proveedor:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="nombre"
                    value="<?= $nombre ?>"
                    placeholder="Ingrese el nombre del proveedor"
                    required>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Nit:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="nit"
                    value="<?= $nit ?>"
                    placeholder="Ingrese el nit del proveedor"
                    required>
            </div>

              <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Telefono:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="telefono"
                    value="<?= $telefono ?>"
                    placeholder="Ingrese el teléfono del proveedor"
                    required>
            </div>

              <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Correo:</b>
                </span>
                <input
                    type="email"
                    class="form-control"
                    name="correo"
                    value="<?= $correo ?>"
                    placeholder="Ingrese el correo del proveedor"
                    required>
            </div>

              <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Dirección:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="direccion"
                    value="<?= $direccion ?>"
                    placeholder="Ingrese la dirección del proveedor"
                    required>
            </div>

              <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Contacto:</b>
                </span>
                <input
                    type="text"
                    class="form-control"
                    name="contacto"
                    value="<?= $contacto ?>"
                    placeholder="Ingrese el contacto del proveedor"
                    required>
            </div>

            <div class="input-group mb-3">
                <label class="input-group-text" for="estado">
                    <b>Estado:</b>
                </label>

                <select class="form-select" id="estado" name="estado" required>
                    <option value="1" <?= ($estado == 1) ? 'selected' : '' ?>>
                        Activo
                    </option>
                    <option value="0" <?= ($estado == 0) ? 'selected' : '' ?>>
                        Inactivo
                    </option>
                </select>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text">
                    <b>Fecha de creación:</b>
                </span>
                <textarea
                    class="form-control"
                    name="fecha_creacion"
                    placeholder="Ingrese la fecha de creación"
                    required><?= $fecha_creacion ?></textarea>
            </div>


            <input type="hidden" name="idproveedor" value="<?= $idproveedor ?>">
            <input type="hidden" name="U_U" value="1">

            <button type="submit" class="btn btn-primary" name="U_U" value="1">
                Actualizar
            </button>

            <a href="../../views/proveedores/index.php" class="btn btn-danger">
                Cancelar
            </a>

        </form>
    </div>

    <div class="col-md-4"></div>
</div>