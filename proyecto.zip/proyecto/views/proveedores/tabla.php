<?php
include_once "../../models/conexion.php";
include_once "../../models/funciones.php";
include_once "../../controllers/funciones.php";

/* Configurar la paginación */
$registrosPorPagina = 5;

// Obtener el número de página
$pagina = isset($_GET['page']) ? (int) $_GET['page'] : 1;

// Evitar páginas menores que 1
if ($pagina < 1) {
    $pagina = 1;
}

// Contar total de proveedores
$sqlTotal = "SELECT COUNT(*) AS total FROM proveedores";
$dataTotal = CRUD($sqlTotal, "S");
$totalRegistros = $dataTotal[0]['total'] ?? 0;

// Calcular total de páginas
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);

// Validar la última página
if ($totalPaginas > 0 && $pagina > $totalPaginas) {
    $pagina = $totalPaginas;
}

// Calcular OFFSET
$offset = ($pagina - 1) * $registrosPorPagina;

// Consultar proveedores
$sql = "SELECT * FROM proveedores
        ORDER BY idproveedor ASC
        LIMIT $registrosPorPagina OFFSET $offset";

$dataProveedores = CRUD($sql, "S");
?>

<!-- Botón para agregar proveedor -->
<a href="crear.php" class="btn btn-primary btn-sm"
    data-bs-toggle="modal"
    data-bs-target="#ModalInsertProveedor">
    <i class="fa-solid fa-user-plus"></i>
</a>

<hr>

<div class="table-responsive">
    <table class="table table-borderless table-bordered table-hover table-sm"
        border="1" style="border-collapse: collapse;">

        <thead class="table-dark p-3">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Nit</th>
                <th>Telefono</th>
                <th>Correo</th>
                <th>Dirección</th>
                <th>Contacto</th>
                <th>Estado</th>
                <th>Fecha de creación</th>
                <th>Acciones</th>
             
            </tr>
        </thead>

        <tbody>
            <?php if (!empty($dataProveedores)): ?>
                <?php foreach ($dataProveedores as $resultado): ?>
                    <tr>
                        <td><?= $resultado['idproveedor']; ?></td>
                        <td><?= $resultado['nombre']; ?></td>
                        <td><?= $resultado['nit']; ?></td>
                        <td><?= $resultado['telefono']; ?></td>
                        <td><?= $resultado['correo']; ?></td>
                        <td><?= $resultado['direccion']; ?></td>
                        <td><?= $resultado['contacto']; ?></td>
                        <td>
                            <?= ($resultado['estado'] != 0)
                                ? 'Activo'
                                : 'Inactivo'; ?>
                        </td>
                        <td><?= $resultado['fecha_creacion']; ?></td>

                        <!-- Botón editar -->
                        <td>
                            <form action="#" method="post">
                                <input type="hidden" name="idproveedor"
                                    value="<?= $resultado['idproveedor']; ?>">

                                <button type="submit"
                                    class="btn btn-success btn-sm"
                                    name="Btn_Update_Proveedor">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" class="text-center">
                        No hay proveedores registrados.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <?php if ($totalRegistros > 0): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">

            <div>
                <small class="text-muted">
                    Página <strong><?= $pagina; ?></strong>
                    de <strong><?= $totalPaginas; ?></strong>
                    | Total de registros:
                    <strong><?= $totalRegistros; ?></strong>
                </small>
            </div>

            <nav aria-label="Paginación de proveedores">
                <ul class="pagination pagination-sm mb-0">

                    <!-- Botón anterior -->
                    <?php if ($pagina > 1): ?>
                        <li class="page-item">
                            <a href="?page=<?= $pagina - 1; ?>"
                                class="page-link">
                                <i class="fa-solid fa-angle-left"></i>
                                Anterior
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                <i class="fa-solid fa-angle-left"></i>
                                Anterior
                            </span>
                        </li>
                    <?php endif; ?>

                    <!-- Números de página -->
                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <?php if ($i == $pagina): ?>
                            <li class="page-item active">
                                <span class="page-link">
                                    <?= $i; ?>
                                </span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="?page=<?= $i; ?>" class="page-link">
                                    <?= $i; ?>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <!-- Botón siguiente -->
                    <?php if ($pagina < $totalPaginas): ?>
                        <li class="page-item">
                            <a href="?page=<?= $pagina + 1; ?>"
                                class="page-link">
                                Siguiente
                                <i class="fa-solid fa-angle-right"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link">
                                Siguiente
                                <i class="fa-solid fa-angle-right"></i>
                            </span>
                        </li>
                    <?php endif; ?>

                </ul>
            </nav>
        </div>
    <?php endif; ?>
</div>