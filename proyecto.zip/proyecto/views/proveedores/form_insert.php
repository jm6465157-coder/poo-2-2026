
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Nombre: </b>
  </span>
  <input type="text" class="form-control" name="nombre" placeholder="Ingrese el nombre del proveedor" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Nit: </b>
  </span>
  <input type="text" class="form-control" name="nit" placeholder="Ingrese el nit del proveedor" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Telefono: </b>
  </span>
  <input type="text" class="form-control" name="telefono" placeholder="Ingrese el teléfono del proveedor" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Correo: </b>
  </span>
  <input type="email" class="form-control" name="correo" placeholder="Ingrese el correo del proveedor" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Dirección: </b>
  </span>
  <input type="text" class="form-control" name="direccion" placeholder="Ingrese la dirección del proveedor" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Contacto: </b>
  </span>
  <input type="text" class="form-control" name="contacto" placeholder="Ingrese el contacto del proveedor" required>
</div>

<div class="input-group mb-3">
    <span class="input-group-text"><b>Estado: </b></span>
    <select class="form-select" name="estado" required>
        <option value="1" selected>Activo</option>
        <option value="0">Inactivo</option>
    </select>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Fecha de creación: </b>
  </span>
  <textarea class="form-control" name="fecha_creacion" placeholder="Ingrese la fecha de creación" required></textarea>
</div>

<input type="hidden" name="I_P" value="1">