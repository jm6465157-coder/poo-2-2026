<?php
session_start();
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if (isset($_POST['I_E']) && $_POST['I_E'] == 1) {

    $nombre = $_POST['nombre'];
    $dui = $_POST['dui'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $cargo = $_POST['cargo'];
    $estado = $_POST['estado'];

    $tabla = "empleados";
    $campo = "nombre, dui, telefono, correo, cargo, estado";
    $valores = "'$nombre', '$dui', '$telefono', '$correo', '$cargo', '$estado'";

    $insert = CRUD("INSERT INTO $tabla ($campo) VALUES ($valores)", "I");

    if ($insert) {
        $_SESSION['mensaje'] = "Empleado registrado correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al registrar el empleado";
    }

    header("Location: ../views/empleados/index.php");
    exit();
}

if (isset($_POST['U_U']) && $_POST['U_U'] == 1) {

    $idempleado = $_POST['idempleado'];
    $nombre = $_POST['nombre'];
    $dui = $_POST['dui'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $cargo = $_POST['cargo'];
    $estado = $_POST['estado'];

    $tabla = "empleados";

    $campo = "nombre='$nombre',
              dui='$dui',
              telefono='$telefono',
              correo='$correo',
              cargo='$cargo',
              estado='$estado'";

    $condicion = "idempleado='$idempleado'";

    $update = CRUD("UPDATE $tabla SET $campo WHERE $condicion", "u");

    if ($update) {
        $_SESSION['mensaje'] = "Empleado actualizado correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar el empleado";
    }

    header("Location: ../views/empleados/index.php");
    exit();
}