<?php
session_start();
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if (isset($_POST['I_P']) && $_POST['I_P'] == 1) {

    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $estado = $_POST['estado'];
    $fecha_creacion = date('Y-m-d H:i:s');

    $tabla = "proveedores";
    $campo = "nombre, nit, telefono, correo, direccion, contacto, estado, fecha_creacion";
    $valores = "'$nombre', '$nit', '$telefono', '$correo', '$direccion', '$contacto', '$estado', '$fecha_creacion'";

    $insert = CRUD("INSERT INTO $tabla ($campo) VALUES ($valores)", "I");

    if ($insert) {
        $_SESSION['mensaje'] = "Proveedor registrado correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al registrar el proveedor";
    }

    header("Location: ../views/proveedores/index.php");
    exit();
}

if (isset($_POST['U_U']) && $_POST['U_U'] == 1) {

    $idproveedor = $_POST['idproveedor'];
    $nombre = $_POST['nombre'];
    $nit = $_POST['nit'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];
    $contacto = $_POST['contacto'];
    $estado = $_POST['estado'];

    $fecha_creacion = $_POST['fecha_creacion'];

    $tabla = "proveedores";

    $campo = "nombre='$nombre',
              nit='$nit',
              telefono='$telefono',
              correo='$correo',
              direccion='$direccion',
              contacto='$contacto',
              estado='$estado',
              fecha_creacion='$fecha_creacion'";

    $condicion = "idproveedor='$idproveedor'";

    $update = CRUD("UPDATE $tabla SET $campo WHERE $condicion", "u");

    if ($update) {
        $_SESSION['mensaje'] = "Proveedor actualizado correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar el proveedor";
    }

    header("Location: ../views/proveedores/index.php");
    exit();
}