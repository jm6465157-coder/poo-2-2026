<?php
session_start();
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if (isset($_POST['I_U']) && isset($_POST['I_U']) == 1) {
    $usuario = $_POST['usuario'];
    $passw = password_hash($_POST['passw'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $rol = $_POST['rol'];

    $tabla = "usuarios";
    $campo = "usuario, passw, email, idrol";
    $valores = "'$usuario', '$passw', '$email', '$rol'";

    $insert = CRUD("INSERT INTO $tabla ($campo) VALUES ($valores)", "I");

    if ($insert) {
        $_SESSION['mensaje'] = "Usuario registrado correctamente";
    } else {
        $_SESSION['error'] = "Error al registrar el usuario";
    }

    header("Location: ../views/usuarios/index.php");
    exit();
}

if (isset($_POST['U_U']) && isset($_POST['U_U']) == 1) {
    $idusuario = $_POST['idusuario'];
    $usuario = $_POST['usuario'];
    if (!empty($_POST['passw'])) {
        $passw = password_hash($_POST['passw'], PASSWORD_DEFAULT);
    }

    $email = $_POST['email'];
    $rol = $_POST['rol'];

    $tabla = "usuarios";
    if (!empty($_POST['passw'])) {
        $campo = "usuario='$usuario', passw='$passw', email='$email', idrol='$rol', '";
    } else {
        $campo = "usuario='$usuario', email='$email', idrol='$rol', '";
    }

    $condicion = "idusuario='$idusuario'";

    $update = CRUD("UPDATE $tabla SET $campo WHERE $condicion", "u");

    if ($update) {
        $_SESSION['mensaje'] = "Usuario actualizado correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar el usuario";
    }

    header("Location: ../views/usuarios/index.php");
    exit();
}

if (isset($_POST['Btn_B_A_User'])) {
    $idusuario = $_POST['idusuario'];
    $valorE = $_POST['valorE'];

    if ($_SESSION['idusuario'] == $idusuario) {
        $_SESSION['mensaje'] = "No puedes cambiar el estado al usuario en sesión";
        header("Location: ../views/usuarios/index.php");
        exit();
    } else {
        $update = CRUD("UPDATE usuarios SET estado='$valorE' WHERE idusuario='$idusuario'", "u");


        if ($update) {
            $_SESSION['mensaje'] = "Estado actualizado";
        } else {
            $_SESSION['mensaje'] = "Error al actualizar el estado";
        }

        header("Location: ../views/usuarios/index.php");
        exit();
    }
}

if (isset($_POST['Btn_Delete_User'])) {
    $idusuario = $_POST['idusuario'];

    if ($_SESSION['idusuario'] == $idusuario) {
        $_SESSION['mensaje'] = "No puedes eliminar el usuario en sesión";
        header("Location: ../views/usuarios/index.php");
        exit();
    } else {
        $update = CRUD("DELETE FROM usuarios  WHERE idusuario='$idusuario'", "d");


        if ($update) {
            $_SESSION['mensaje'] = "Usuario eliminado";
        } else {
            $_SESSION['mensaje'] = "Error al eliminar Usuario";
        }

        header("Location: ../views/usuarios/index.php");
        exit();
    }
}
