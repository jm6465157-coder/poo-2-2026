<?php
session_start();

include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if(isset($_POST['I_U']) && $_POST['I_U'] == 1){
    $usuario = $_POST['usuario'];
    $passw = password_hash($_POST['passw'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $rol = $_POST['rol'];

    $tabla = "usuarios";
    $campos = "usuario, passw, email, idrol";
    $valores = "'$usuario', '$passw', '$email', '$rol'";

    $insert = CRUD("INSERT INTO $tabla ($campos) VALUES ($valores)", "i");

    if($insert){
        $_SESSION['mensaje'] = "Usuario registrado correctamente";
    }else{
        $_SESSION['error'] = "Error al registrar usuario";
    }
     header("Location: ../views/usuarios/index.php");
     exit();
}    elseif(isset()){

}



?>