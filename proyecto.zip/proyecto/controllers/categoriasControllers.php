<?php
session_start();
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if (isset($_POST['I_C']) && $_POST['I_C'] == 1) {

    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $fecha_creacion = date('Y-m-d H:i:s');

    $tabla = "categorias";
    $campo = "nombre, descripcion, estado, fecha_creacion";
    $valores = "'$nombre', '$descripcion', '$estado', '$fecha_creacion'";

    $insert = CRUD("INSERT INTO $tabla ($campo) VALUES ($valores)", "I");

    if ($insert) {
        $_SESSION['mensaje'] = "Categoría registrada correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al registrar la categoría";
    }

    header("Location: ../views/categorias/index.php");
    exit();
}

if (isset($_POST['U_U']) && $_POST['U_U'] == 1) {

    $idcategoria = $_POST['idcategoria'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];

    $fecha_creacion = $_POST['fecha_creacion'];

    $tabla = "categorias";

    $campo = "nombre='$nombre',
              descripcion='$descripcion',
              estado='$estado',
              fecha_creacion='$fecha_creacion'";

    $condicion = "idcategoria='$idcategoria'";

    $update = CRUD("UPDATE $tabla SET $campo WHERE $condicion", "u");

    if ($update) {
        $_SESSION['mensaje'] = "Categoría actualizada correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar la categoría";
    }

    header("Location: ../views/categorias/index.php");
    exit();
}