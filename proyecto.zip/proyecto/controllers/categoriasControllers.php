<?php
session_start();
include "../models/conexion.php";
include "../models/funciones.php";

if (isset($_POST['U_C'])) {
    $idcategoria = $_POST['idcategoria'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];

    // Consulta 
    $sql = "UPDATE categorias SET nombre = '$nombre', descripcion = '$descripcion', estado = '$estado' WHERE idcategoria = $idcategoria";

    $resultado = CRUD($sql, "C");

    if ($resultado) {
        $_SESSION['mensaje'] = "Categoría actualizada correctamente";
    } else {
        $_SESSION['mensaje'] = "Error al actualizar la categoría";
    }

    header("Location: ../views/categorias/index.php");
    exit();
}
