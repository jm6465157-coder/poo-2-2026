<?php
class Procesos
{
    // GDU = Get Data User
    public function GDU($user, $tabla, $campo)
    {
        $row = [];

        $modelo = new Conexion();
        $conexion = $modelo->getConexion();

        try {
            $query = "SELECT * FROM usuarios
                      WHERE usuario = :usuario
                      OR email = :email
                      LIMIT 1";

            $stmt = $conexion->prepare($query);
            $stmt->bindValue(':usuario', $user);
            $stmt->bindValue(':email', $user);
            $stmt->execute();

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            return $row;
        } catch (PDOException $e) {
            return [];
        } finally {
            $modelo->closeConexion();
        }
    }

    // sidu = SELECT INSERT DELETE UPDATE
    public function sidu($query, $accion)
    {
        $row = [];
        $modelo = new Conexion();
        $conexion = $modelo->getConexion();
        $stmt = null;

        try {
            $stmt = $conexion->prepare($query);

            if (!$stmt) {
                return 0;
            }

            if ($accion == "S" || $accion == "s") {
                $stmt->execute();

                while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $row[] = $result;
                }

                return $row;
            } else {
                $stmt->execute();
                return 1;
            }
        } catch (PDOException $e) {
            return 0;
        } finally {
            $stmt = null;
            $modelo->closeConexion();
        }
    }
}
