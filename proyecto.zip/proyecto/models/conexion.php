<?php
class Conexion{
    private $sistema = 'PHP OF FAMILY';

    private $pdo;
    private $dsn = 'mysql:host=localhost;dbname=crud;charset=utf8mb4';
    private $user;
    private $pass;

    public function __construct()
    {
        if($this->sistema === 'Windows'){
            $this->user = 'root';
            $this->pass = '';
        } else {
            $this->user = 'toor';
            $this->pass = 'toor';
        }
        try{
            $this->pdo = new PDO(
                $this->dsn,
                $this->user,
                $this->pass
            );

            $this->pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            //echo "Conexion exitosa...";
        } catch(PDOException $e){
            echo "Error: ".$e->getMessage();
        }
    }

    public function getConexion(){
        return $this->pdo;
    }

    public function closeConexion(){
        $this->pdo = null;
    }
}